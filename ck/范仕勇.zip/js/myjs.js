		 
			var wow = new WOW({  
		    boxClass: 'wow',  
		    animateClass: 'animated',  
		    offset: 80,  
		    mobile: true,  
		    live: true  
			});  
				wow.init();  

				
				$(".bannerbox img").css("height",$(window).height());
	
				 
				 $(window).scroll(function(){
				 	
				 	 
//				 	返回顶部
					   var sc=$(window).scrollTop(); 
					   var wh=$(window).height();
					   var rwidth=$(window).width()
					   var aw=$(".ahover").width();
					   if(sc>30){
					   	
						if((sc/($(window).height()/2))<0.6){
					    		$(".navbar-fixed-top").css("background","rgba(0,0,0,"+sc/($(window).height()/2)+")")
					    };
					    $("#goTopBtn").css("display","block");
					    $("#goTopBtn").css("left",(rwidth-56)+"px")
					   }else{
					   	$(".navbar-fixed-top").css("background","rgba(0,0,0,0.6)")
					   $("#goTopBtn").css("display","none");
					   };
					   if(sc>wh){
					   	  $("#email").css("display","block");
					    $("#email").css("left",(rwidth-56)+"px")
					   }else{
					   	  $("#email").css("display","none"); 
					   }
				 });
				 $("#goTopBtn").click(function(){
				   var sc=$(window).scrollTop();
				   $('body,html').animate({scrollTop:0},500);
				 })
				
		